// The scroll bar style only works in Google Chrome
